# DCAR‑S Telegram Booking Bot

Бот для записи на автомойку. Команды:

- /start — начать бронирование
- /cancel — отменить

## Установка и запуск:

```bash
pip install -r requirements.txt
export BOT_TOKEN=ваш_токен_от_BotFather
python bot.py
```
